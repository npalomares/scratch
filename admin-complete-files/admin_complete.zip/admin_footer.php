 
    <div id="footer">
    	<p>&copy; 2012 Platt College</p>
    </div><!-- end #footer -->

</div><!-- end #wrapper -->
</body>
</html>