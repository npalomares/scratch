<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<?php

//read the exif from some image (fill in the path here)
$exif = exif_read_data('uploads/avatar_1fc5a317c215cb5d5818ffe6237dd042aa731d5e.jpg', 0, true);


if($exif){
	echo "<h2>Exif for default.jpg:<br />\n</h2>";
	
	//multidimensional array (list of lists) comes back from exif_read_data, so we have to run a couple of loops to get all the info out
	foreach ($exif as $key => $section) {
		foreach ($section as $name => $val) {
			echo "$key.$name: $val<br />\n";
		}
	}
}else{
	echo 'no exif!';	
}
?>

</body>
</html>