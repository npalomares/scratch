<?php 
//parse the form submission
if( $_POST['did_post'] == 1 ){
	//extract and sanitize data
	$title = clean_input($_POST['title']);
	$body = clean_input($_POST['body']);
	$category = clean_input($_POST['category']);
	$allow_comments = clean_input($_POST['allow_comments']);
	$is_published = clean_input($_POST['is_published']);
	
	//validate
	//if checkboxes are left blank, convert to 0 for the DB
	if( $allow_comments == '' ){
		$allow_comments = 0;		
	}
	if( $is_published == '' ){
		$is_published = 0;
	}
	
	//GO! put info in DB
	$query_insert = "INSERT INTO posts
			( title, body, date, user_id, category_id, is_published, allow_comments )
					VALUES
	( '$title', '$body', now(), $user_id, $category, $is_published, $allow_comments )";
	
	$result_insert = mysql_query($query_insert);
	//make sure one row went into DB
	if( mysql_affected_rows() == 1 ){
		echo 'Your Post was successfully added.';
	}else{
		echo 'Sorry, something went wrong and your post was not saved.';	
	}
}//end if submitted form
?>
<h2>Write Post</h2>

<form action="admin.php?page=write" method="post">
	<label for="title">Title:</label>
    <input type="text" name="title" id="title" />
    
    <label for="body">Post Content:</label>
    <textarea name="body" id="body" cols="45" rows="5"></textarea>
    
    <label for="category">Category:</label>
    <select name="category" id="category">
    	<?php
		//get all categories in alphabetical order by name
		$query_cats = "SELECT *
						FROM categories
						ORDER BY name ASC";
		$result_cats = mysql_query($query_cats);
		
		while( $row_cats = mysql_fetch_array($result_cats) ){
		 ?>
    	<option value="<?php echo $row_cats['category_id']; ?>">
			<?php echo $row_cats['name']; ?>
        </option>
       <?php } //end while cats ?>
       
    </select>
    
    <label>
    	<input type="checkbox" name="allow_comments" id="allow_comments" value="1" checked="checked" />
        Allow Comments on this post?
    </label>
    
    <label>
    	<input type="checkbox" name="is_published" id="is_published" value="1" checked="checked" />
        Make this post public?
    </label>
    
    <input type="submit" value="Save Post" />
    <input type="hidden" name="did_post" value="1" />
</form>