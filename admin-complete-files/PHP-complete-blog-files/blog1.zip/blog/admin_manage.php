<h2>Manage Your Posts</h2>

<ul>
	<?php //get the title and id of all posts by logged in user
	$query_posts = "SELECT title, post_id, is_published
					FROM posts
					WHERE user_id = $user_id
					ORDER BY date DESC";
	$result_posts = mysql_query($query_posts);
	//make sure there are posts
	if( mysql_num_rows($result_posts) >= 1 ){
		while( $row_posts = mysql_fetch_array($result_posts) ){					
	 ?>
     
	<li><a href="admin.php?page=edit&amp;postid=<?php echo $row_posts['post_id']; ?>">
		<?php echo $row_posts['title']; ?>
        <?php //if the post is not published, show a draft tag
			if( $row_posts['is_published'] == 0 ){
				echo ' - <em>Draft</em>';
			}
		 ?>
        
    </a></li>
    
    <?php 
		}//end while there are posts
	} // end if there are posts
	else{
		echo '<li>You have not written any posts yet.</li>';	
	}
	 ?>
</ul>