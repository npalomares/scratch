<h2>All Blog Posts</h2>

<?php 
// get 2 latest published posts
$query_latest = "SELECT title, body, date, category_id, post_id
				FROM posts 
				WHERE is_published = 1
				ORDER BY date DESC";

//run the query code on the DB
$result_latest = mysql_query( $query_latest );

//loop it, work with one post at a time
while( $row_latest = mysql_fetch_array( $result_latest ) ){
 ?>
<div class="post">
    <h2><?php echo $row_latest['title']; ?></h2>
    <h3>Posted on <?php echo $row_latest['date']; ?> in the category SOMETHING</h3>
    
    <p><?php echo $row_latest['body']; ?></p>
</div>

<?php } //end while loop ?>

