<?php 
//register parse. all this logic MUST go before the doctype or any other text output.
session_start();
require('db_config.php');
require_once('functions.php');

//if they submitted the form, parse it
if( $_POST['did_register'] == 1 ){
	//extract and sanitize all fields
	$username = clean_input($_POST['username']);
	$email = clean_input($_POST['email']);
	$password = clean_input($_POST['password']);
	$repassword = clean_input($_POST['repassword']);
	$policy = clean_input($_POST['policy']);
	
	//encrypted version of the password, for storing in DB
	$sha_password = sha1($password);
	
	//begin validation
	$valid = true;
	
	//did they forget to check the box?
	if( $policy != 1 ){
		$valid = false;
		$msg = 'You must agree to the TOS and PP before signing up. <br />';
	}
	
	//repeated password does not match
	if( $password != $repassword ){
		$valid = false;
		$msg .= 'The passwords provided do not match. <br />';
	}
	
	//make sure the username and password are at least 5 chars long, then check the DB 
	if( strlen($username) >= 5 AND strlen($password) >= 5 ){
		//check to see if username is already taken
		$query_username = "SELECT username 
							FROM users
							WHERE username = '$username'
							LIMIT 1";
		$result_username = mysql_query($query_username);
		//if one result is found, UN is taken.
		if( mysql_num_rows($result_username) == 1 ){
			$valid = false;
			$msg .= 'That username is already taken. Try another. <br />';
		}
	}else{
		//too short
		$valid = false;
		$msg .= 'Username and Password must be at least 5 characters long.<br />';	
	}
	
	//check for valid email, then check for match in database
	if( check_email_address($email) == true ){
		//look for match in DB
		$query_email = "SELECT email
						FROM users
						WHERE email = '$email'
						LIMIT 1";
		$result_email = mysql_query($query_email);
		//if 1 result found, email is taken.
		if( mysql_num_rows($result_email) == 1 ){
			$valid = false;
			$msg .= 'Looks like an account with that email already exists. Do you want to login? <br />';
		}
	}else{
		//invalid email
		$valid = false;
		$msg .= 'Please provide a valid email address.<br />';
	}
	
	//if the data passed ALL tests, add the user to the DB
	if( $valid == true ){
		$query_insert = "INSERT INTO users
						(username, password, email, join_date, is_admin)
						VALUES
						('$username', '$sha_password', '$email', now(), 0)";
		$result_insert = mysql_query($query_insert);
		//check to see if it worked
		if( mysql_affected_rows() == 1 ){
			//SUCCESS! Log the user in and send them to their profile
			$_SESSION['logged_in'] = true;
			setcookie( 'logged_in', 'true', time() + 60*60*24*7 );
			header('location:admin.php');			
		}else{
			$msg .= 'There was a problem adding the user to the DB';
		}
		
	}
	
	
} //end if submitted form 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Sign up for an account</title>
<style type="text/css">
label{
	display:block;	
}
input[type=submit]{
	display:block;	
}
input[type=checkbox]{
	display:block;	
}

</style>
</head>

<body>
<div id="wrapper">
	<h1>Sign Up</h1>
    <?php
	if( isset($msg) ){
		echo $msg;		
	}
	 ?>
    <form action="register.php" method="post">
    	<label for="username">Choose a Username:</label>
        <input type="text" name="username" id="username" />
        <span class="hint">Minimum of 5 characters long</span>
        
        <label for="email">Your Email Address:</label>
        <input type="text" name="email" id="email" />
        
        <label for="password">Choose a Password:</label>
        <input type="password" name="password" id="password" />
        <span class="hint">Minimum of 5 characters long</span>
        
        <label for="repassword">Repeat password:</label>
        <input type="password" name="repassword" id="repassword" />
        
        <input type="checkbox" name="policy" id="policy" value="1" />
        <label for="policy">Yes, I have read the Terms of Service and Privacy Policy.</label>
        <input type="submit" value="Sign Up" />
        <input type="hidden" name="did_register" value="1" />
     </form>
</div>
</body>
</html>