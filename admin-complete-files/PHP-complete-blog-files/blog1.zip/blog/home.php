<?php 
// get 2 latest published posts
$query_latest = "SELECT posts.title, posts.body, posts.date, posts.category_id, posts.post_id, categories.name
				FROM posts, categories 
				WHERE posts.is_published = 1
				AND posts.category_id = categories.category_id
				ORDER BY posts.date DESC
				LIMIT 2";

//run the query code on the DB
$result_latest = mysql_query( $query_latest );

//loop it, work with one post at a time
while( $row_latest = mysql_fetch_array( $result_latest ) ){
	
	//separate query to count the number of comments on THIS post
	//get the post_id of THIS post
	$post_id = $row_latest['post_id'];
	//set up count query
	$query_count = "SELECT COUNT(*) AS total
					FROM comments
					WHERE post_id = $post_id";
	//run it
	$result_count = mysql_query( $query_count );
	//no need to loop a count query, it only returns one result 
	$row_count = mysql_fetch_array( $result_count );
 ?>
<div class="post">
    <h2><?php echo $row_latest['title']; ?></h2>
    <h3>Posted on <?php echo convert_date($row_latest['date']); ?> 
    in the category <?php echo $row_latest['name']; ?>. 
    This post has <?php echo $row_count['total'] ?> <?php //logic for singular/plural comments
	if( $row_count['total'] == 1 ){
		echo 'comment';
	}else{
		echo 'comments';	
	}
	
	 ?></h3>
    
    <p><?php echo $row_latest['body']; ?></p>
</div>

<?php } //end while loop ?>

<a href="index.php?page=blog">Read all blog posts</a>

<hr />

<h2>About the author:</h2>
<p>I like turtles... and baby ducks.</p>