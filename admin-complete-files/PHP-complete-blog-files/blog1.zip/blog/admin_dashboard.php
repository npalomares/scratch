<h2>Welcome to your dashboard!</h2>

<h3>Your Latest Posts:</h3>
<ul>
<?php //get the latest 3 posts for the logged in user
$query_latest = "SELECT title, post_id
				 FROM posts
				 WHERE user_id = $user_id
				 ORDER BY date DESC
				 LIMIT 3";
$result_latest = mysql_query($query_latest);
//check to see if there are posts
if( mysql_num_rows($result_latest) >= 1 ){
	//loop through results
	while( $row_latest = mysql_fetch_array($result_latest) ){ ?>
		
        <li><?php echo $row_latest['title']; ?></li>
        
    <?php } //end while ?>
<?php } //end if there are posts ?>
</ul>

<h3>Latest comments on your posts:</h3>
<ul>
	<li>COMMENT - on TITLE</li>
    <li>COMMENT - on TITLE</li>
    <li>COMMENT - on TITLE</li>
</ul>