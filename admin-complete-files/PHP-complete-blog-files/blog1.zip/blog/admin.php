<?php
session_start();
require('db_config.php');
require_once('functions.php');

//if the cookie is still valid, recreate the session
if( $_COOKIE['logged_in'] == true){
	$_SESSION['logged_in'] = true;
	$_SESSION['user_id'] = $_COOKIE['user_id'];
	$_SESSION['is_admin'] = $_COOKIE['is_admin'];	
}

//make sure they are logged in
if( $_SESSION['logged_in'] != true ){
	//not logged in!  send them back to the form
	header('location:login.php');
}

//extract the data for the logged in user, so we can use it on all pages
$user_id = $_SESSION['user_id'];
$query_user = "SELECT * FROM users
				WHERE user_id = $user_id
				LIMIT 1";
$result_user = mysql_query($query_user);
$row_user = mysql_fetch_array($result_user);
//this is going to be a handy variable to have on all pages
$user_id = $row_user['user_id'];
				
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Manage your Blog</title>

<style type="text/css">
	label,
	input[type=submit]{
		display:block;
	}
</style>
</head>

<body>
<div id="wrapper">
	<div id="header">
		<h1>My Blog Admin Panel</h1>
        
        <ul class="utilities">
        	<li>You are logged in as <?php echo $row_user['username']; ?></li>
        	<li><a href="index.php">View Blog</a></li>
            <li><a href="login.php?action=logout">Log Out</a></li>
        </ul>
        
        <ul class="main_menu">
        	<li><a href="admin.php">Dashboard</a></li>
            <li><a href="admin.php?page=write">Write Post</a></li>
            <li><a href="admin.php?page=manage">Manage Posts</a></li>
            <li><a href="admin.php?page=comments">Manage Comments</a></li>
            <li><a href="admin.php?page=upload">Edit Profile</a></li>
        </ul>
    </div>
    
    <div id="content">
    	<?php 
			//figure out what page to show. URI will look like admin.php?page=something
			$page = $_GET['page'];
			switch( $page ){
				case 'write':
					include('admin_write.php');
				break;
				case 'manage':
					include('admin_manage.php');
				break;
				case 'edit':
					include('admin_edit.php');
				break;
				case 'upload':
					include('upload.php');
				break;
				case 'comments':
					include('admin_comments.php');
				break;
				default:
					include('admin_dashboard.php');
			}
		?>        
    </div>
    
    <div id="footer">
    	&copy; 2012 Melissa C.
    </div>
</div>
</body>
</html>