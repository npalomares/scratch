<script language="javascript" type="text/javascript">
function confirmSubmit(){
	var agree = confirm("Deleting comments is permanent. There is no undo. Are you sure?");
	if(agree){
		return true;	
	}else{
		return false;	
	}
		
}
</script>

<?php 
if($_POST['did_delete'] == 1){
	//the list of comments to delete is in an array called delete[]
	$delete_list = $_POST['delete'];
	//do nothing if the delete array is blank
	if( $delete_list != '' ){
		
		//loop through the items in the list, deleting comments one at a time
		foreach( $delete_list as $comment_id ){
			$query_delete = "DELETE FROM comments
							WHERE comment_id = $comment_id
							LIMIT 1";
			$result_delete = mysql_query($query_delete);
			
		}
		$count = count($delete_list);
		$msg = $count.' comments were deleted';
		
		
	}// end if is not blank
	else{
		$msg = 'You did not check any comments!';	
	}
}//end if submitted form

?>

<h2>Manage Comments</h2>

<?php if( isset($msg) ){
	echo $msg;
}?>

<form action="admin.php?page=comments" method="post">
<ul>

	<?php //get all posts belonging to the logged in user that have comments
	$query_posts = "SELECT distinct posts.*
					FROM posts, comments
					WHERE posts.user_id = $user_id
					AND posts.post_id = comments.post_id
					ORDER BY comments.date DESC
					LIMIT 10";
	$result_posts = mysql_query($query_posts);
	//make sure there are posts
	if( mysql_num_rows($result_posts) >= 1 ){
		while( $row_posts = mysql_fetch_array($result_posts) ){
	 ?>
	<li><?php echo $row_posts['title']; ?>
    	<ul>
        
        	<?php //get all comments on THIS post 
			$post_id = $row_posts['post_id'];
			$query_comm = "SELECT * 
							FROM comments
							WHERE post_id = $post_id
							ORDER BY date DESC";
			$result_comm = mysql_query($query_comm);
			while( $row_comm = mysql_fetch_array($result_comm) ){
			?>
            
        	<li>
          <input type="checkbox" name="delete[<?php echo $row_comm['comment_id'] ?>]" id="delete_<?php echo $row_comm['comment_id'] ?>" value="<?php echo $row_comm['comment_id'] ?>" /> 
            
            <?php echo $row_comm['body']; ?> - by <?php echo $row_comm['name']; ?>
            </li>
            
            <?php } //end while comments ?>
        </ul>
    </li>

    <?php 
		} //end while there are posts
	} //end if there are posts
	else{
		echo '<li>You don\'t have any comments yet!</li>';	
	}?> 
    
</ul>
<input type="submit" value="Delete Checked Comments" onClick="return confirmSubmit()" />
<input type="hidden" name="did_delete" value="1" />
</form>