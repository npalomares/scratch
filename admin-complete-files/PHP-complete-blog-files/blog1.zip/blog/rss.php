<?php 
require('db_config.php');
function convTimestamp($date){
  $year   = substr($date,0,4);
  $month  = substr($date,5,2);
  $day    = substr($date,8,2);
  $hour   = substr($date,11,2);
  $minute = substr($date,14,2);
  $second = substr($date,17,2);
  $stamp =  date('D, d M Y H:i:s O', mktime($hour, $min, $sec, $month, $day, $year));
  return $stamp;
}
echo '<?xml version="1.0" encoding="iso-8859-1"?>'; ?>
<rss version="2.0">
<channel>
	<?php //channel represents the whole feed ?>
    <title>Melissa's Blog</title>
    <link>http://localhost/melissa_june12/blog</link>
    <description>Good stuff. No kids falling down, though.</description>
    <webMaster>melissacabral@gmail.com</webMaster>
    <managingEditor>melissacabral@gmail.com</managingEditor>
    <category>Entertainment</category>
    <docs>http://blogs.law.harvard.edu/tech/rss</docs>
    <pubDate><?php date('r'); ?></pubDate>
    <lastBuildDate><?php date('r'); ?></lastBuildDate>
    <language>en-us</language>
    <image>
    	<url>http://localhost/melissa_june12/blog/images/roly.gif</url>
        <title>my blog's logo</title>
        <link>http://localhost/melissa_june12/blog</link>
    </image>
    <?php //get the latest 10 published posts
	$query = "SELECT title, post_id, date, body
				FROM posts
				WHERE is_published = 1
				ORDER BY date DESC
				LIMIT 10";
	//run it
	$result = mysql_query($query);
	
	//loop it
	while( $row = mysql_fetch_array($result) ){	
	 ?>
    <item>
    	<title><?php echo htmlentities($row['title']); ?></title>
  <link>http://localhost/melissa_june12/blog/index.php?page=single&amp;postid=<?php  echo $row['post_id']; ?></link>
  <guid>http://localhost/melissa_june12/blog/index.php?page=single&amp;postid=<?php  echo $row['post_id']; ?></guid>
		<pubDate><?php echo convTimestamp($row['date']); ?></pubDate>
        <description><?php echo htmlentities($row['body']); ?></description>
    </item>
    <?php } ?>
    
</channel>
</rss>