<?php
//connect to db server
$db = mysql_connect( 'localhost', 'blog_mc_user', 'somepassword' );
//choose the right db
mysql_select_db( 'blog_mc', $db ) or die( 'Could not connect to DB' );