<?php 
if( $_POST['did_upload'] == 1 ){
//file uploading stuff begins
//make sure your site has a uploads directory in the same directory as this file	
	$target_path = "uploads/";
	
	
	
	
	// This is the temporary file created by PHP
$uploadedfile = $_FILES['uploadedfile']['tmp_name'];
// Capture the original size of the uploaded image
list($width,$height)=getimagesize($uploadedfile);

// For our purposes, I have resized the image to be
// 200 pixels wide, and maintain the original aspect
// ratio. This prevents the image from being "stretched"
// or "squashed". If you prefer some max width other than
// 200, simply change the $newwidth variable

if($width > 0 AND $height > 0){
//we have a winner

if($width >= 200){
	$newwidth=200;
	$newheight=($height/$width)*$newwidth;
}else{
	$newwidth=$width;
	$newheight=$height;
}


$filetype = $_FILES['uploadedfile']['type'];

switch($filetype){
	case 'image/gif':
		// Create an Image from it so we can do the resize
		$src = imagecreatefromgif($uploadedfile);
	break;
	case 'image/pjpeg':
    case 'image/jpg':
    case 'image/jpeg': 
		// Create an Image from it so we can do the resize
		$src = imagecreatefromjpeg($uploadedfile);
	break;
	case 'image/x-png':
		// Create an Image from it so we can do the resize
		
	break;
	case 'image/png':
		// Create an Image from it so we can do the resize
		$required_memory = Round($width * $height * $size['bits']);
		$new_limit=memory_get_usage() + $required_memory;
		ini_set("memory_limit", $new_limit);
		$src = imagecreatefrompng($uploadedfile);
		ini_restore ("memory_limit");
	break;
	default:
		
}




$tmp=imagecreatetruecolor($newwidth,$newheight);

// this line actually does the image resizing, copying from the original
// image into the $tmp image
imagecopyresampled($tmp,$src,0,0,0,0,$newwidth,$newheight,$width,$height);

// now write the resized image to disk. I have assumed that you want the
// resized, uploaded image file to reside in the ./images subdirectory.
$randomsha = sha1(microtime());
$filename = $target_path.'avatar_'.$randomsha.'.jpg';
//$filename = $target_path. $_FILES['uploadedfile']['name'];
$didcreate = imagejpeg($tmp,$filename,70);
//creates image and in the parameters has variables on how its made and the number is the percent of quality
imagedestroy($src);
imagedestroy($tmp); // NOTE: PHP will clean up the temp file it created when the request
// has completed.
	
	
}else{
	$didcreate = false;
}//width and height not greater than 0

		
	if($didcreate) {
	
		//success! update the user info in DB
		$query = "UPDATE users
				SET avatar_link = '$filename'
				WHERE user_id = $user_id ";
		$result = mysql_query($query);
		
		//check to make sure it went into DB
		if( mysql_affected_rows() == 1 ){
			$statusmsg = 'Filepath added to DB.<br />';
		}else{
			$statusmsg = 'Database not updated.<br />';	
		}
		
		$statusmsg .=  "The file ".  basename( $_FILES['uploadedfile']['name']). 
		" has been uploaded <br />";
	} else{
		$statusmsg .= "There was an error uploading the file, please try again!<br />";
	}	
}//end if form submitted
?>


<h2>Edit Your Avatar</h2>

<?php
if( isset($statusmsg) ){
	echo $statusmsg;
}
 ?>

<form action="admin.php?page=upload" method="post" enctype="multipart/form-data">

	<label for="uploadedfile">Choose a File:</label>
    <input type="file" name="uploadedfile" id="uploadedfile" />
    
    <input type="submit" value="Upload File" />
    
    <input type="hidden" name="did_upload" value="1" />

</form>


<h2>Your Current Avatar:</h2>

<?php 
$query_pic = "SELECT username, avatar_link
				FROM users
				WHERE user_id  = $user_id
				LIMIT 1";
$result_pic = mysql_query($query_pic);

//make sure the query worked
if( mysql_num_rows($result_pic) == 1 ){
	//extract the data
	$row_pic = mysql_fetch_array($result_pic);
	
	//check to see if the user has an avatar (field not blank)
	if( $row_pic['avatar_link'] != '' ){
		echo '<img src="'.$row_pic['avatar_link'].'" title="USER\'s picture" />';
	}else{
		echo '<img src="images/default.jpg" />';
	}
	
}

 ?>










