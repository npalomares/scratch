<?php
//which post are we showing? get the postid out of the url
$post_id = $_REQUEST['postid'];

//PARSE THE COMMENT FORM IF THEY SUBMIT THE FORM
if( $_POST['did_comment'] == 1 ){
	//clean up the submitted data
	$name = clean_input($_POST['name']);
	$email = clean_input($_POST['email']);
	$url = clean_input($_POST['url']);
	$comment = clean_input($_POST['comment']);
	
	//TODO: validate here
	
	//insert comment into DB!
	$query_insert = "INSERT INTO comments
					(name, email, url, body, date, is_approved, post_id)
					VALUES
					('$name', '$email', '$url', '$comment', now(), 1, $post_id)";
	//run it
	$result_insert = mysql_query($query_insert);
	//make sure one row was added to the table
	if( mysql_affected_rows() == 1 ){
		$message = "Thanks for your comment!";
	}else{
		$message = "There was a problem posting your comment. >____<";	
	}
	
	
}//end if form submitted




 
// get the post we are trying to view. only if it is published
$query_latest = "SELECT posts.title, posts.body, posts.date, posts.category_id, posts.post_id, categories.name
				FROM posts, categories 
				WHERE posts.is_published = 1
				AND posts.category_id = categories.category_id
				AND posts.post_id = $post_id
				ORDER BY posts.date DESC
				LIMIT 1";

//run the query code on the DB
$result_latest = mysql_query( $query_latest );

//loop it, work with one post at a time
while( $row_latest = mysql_fetch_array( $result_latest ) ){
	
	//separate query to count the number of comments on THIS post
	//get the post_id of THIS post
	$post_id = $row_latest['post_id'];
	//set up count query
	$query_count = "SELECT COUNT(*) AS total
					FROM comments
					WHERE post_id = $post_id";
	//run it
	$result_count = mysql_query( $query_count );
	//no need to loop a count query, it only returns one result 
	$row_count = mysql_fetch_array( $result_count );
 ?>
<div class="post">
    <h2><?php echo $row_latest['title']; ?></h2>
    <h3>Posted on <?php echo convert_date($row_latest['date']); ?> 
    in the category <?php echo $row_latest['name']; ?>. 
    This post has <?php echo $row_count['total'] ?> <?php //logic for singular/plural comments
	if( $row_count['total'] == 1 ){
		echo 'comment';
	}else{
		echo 'comments';	
	}
	
	 ?></h3>
    
    <p><?php echo $row_latest['body']; ?></p>
</div>

<?php } //end while loop ?>

<a href="index.php?page=blog">Read all blog posts</a>

<hr />


<ul class="comment-list">
	<?php 
	//get all comments on THIS post
	$query_comment = "SELECT * 
						FROM comments
						WHERE is_approved = 1
						AND post_id = $post_id";
	//run it
	$result_comment = mysql_query($query_comment);
	//make sure there is at least one comment
	if( mysql_num_rows($result_comment) >= 1 ){
		//loop through the comments
		while($row_comment = mysql_fetch_array($result_comment)){	
	?>
    
    <li>  
    	<h3><?php echo $row_comment['name']; ?> Said:</h3>
        <p><?php echo $row_comment['body']; ?></p>
        <p><?php echo $row_comment['date']; ?></p>
    </li>
    
    <?php 
		}//end while
	} //end if there are comments
	else{ //no comments
		 echo '<li>No Comments Yet!</li>';	
	}
	 ?>

</ul>

<a name="leavecomment"></a>
<h3>Leave a Comment:</h3>

<?php 
//if there is a message, show it
if( isset($message) ){
	echo $message;
}
 ?>


<form method="post" action="#leavecomment">
	<label for="name">Your Name:</label>
    <input type="text" name="name" id="name" />
    <br />
    <label for="email">Email Address:</label>
    <input type="text" name="email" id="email" />
    <br />
    <label for="url">Your Website:</label>
    <input type="text" name="url" id="url" placeholder="http://" />
    <br />
    <label for="comment">Your Comment:</label>
    <textarea name="comment" id="comment" cols="45" rows="5"></textarea>
    <br />
    <input type="submit" value="Leave a Comment" />
    
    <input type="hidden" name="did_comment" value="1" />
</form>





