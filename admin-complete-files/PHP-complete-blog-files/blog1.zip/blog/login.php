<?php
//put this at the top of any page that needs to use session data
session_start();
require('db_config.php');
require_once('functions.php');


//parse the login form if they pressed the button
if( $_POST['did_login'] == 1 ){
	
	//extract user-submitted data from all fields, CLEAN IT UP.
	$input_username = clean_input( $_POST['username'] );
	$input_password = clean_input( $_POST['password'] );
	$sha_password = sha1($input_password);
	
	//validate. make sure un and password are at least 5 characters long
	if( strlen( $input_username ) >= 5 AND strlen( $input_password ) >= 5 ){
		//look for one user with matching info in the DB
		$query_login = "SELECT user_id, is_admin
						FROM users
						WHERE username = '$input_username'
						AND password = '$sha_password'
						LIMIT 1 ";
		$result_login = mysql_query($query_login);
		
		//if one record is found, log them in!
		if( mysql_num_rows($result_login) == 1 ){
			//extract the data from the query result so we know the user ID and admin status
			$row_login = mysql_fetch_array($result_login);
			//success. set cookies and sessions
			setcookie( 'logged_in', 'true', time() + 60 * 60 * 24 * 7 );
			setcookie( 'user_id', $row_login['user_id'], time() + 60 * 60 * 24 * 7 );
			setcookie( 'is_admin', $row_login['is_admin'], time() + 60 * 60 * 24 *7 );
			
			//for every cookie, make a session variable
			$_SESSION['logged_in'] = true;
			$_SESSION['user_id'] = $row_login['user_id'];
			$_SESSION['is_admin'] = $row_login['is_admin'];
			
			//redirect to profile
			header( 'location:admin.php' );
			
		}else{
			//username and password do not match
			$error = true;	
		}//end username/password mismatch
	}//end validation
	else{
		//un or password too short, show error
		$error = true;		
	}
} //end if pressed button

//if the user pressed log out
if( $_GET['action'] == 'logout' ){
	//unset each session var
	unset( $_SESSION['logged_in'] );
	unset( $_SESSION['user_id'] );
	unset( $_SESSION['is_admin'] );
	session_destroy(); //wipes out the session_id
	//set all cookies to blank values
	setcookie( 'logged_in', '' );
	setcookie( 'user_id', '' );	
	setcookie( 'is_admin', '' );	
}

//if the user returns and the cookie is still valid, recreate the session
elseif($_COOKIE['logged_in'] == 'true'){
	$_SESSION['logged_in'] = true;	
	$_SESSION['user_id'] = $_COOKIE['user_id'];
	$_SESSION['is_admin'] = $_COOKIE['is_admin'];
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Log in to your account</title>
</head>

<body>
<h1>Log in!</h1>

<?php //show an error if there is a problem with the login
if( $error == true ){ ?>

	<div class="error">
    	Sorry, Your username and password are incorrect. Try again. 
    </div>	
     
<?php } //end if error ?>


<?php //show the form only if NOT logged in
if( !$_SESSION['logged_in'] ){
?>
<form action="login.php" method="post">
	
    <label for="username">Username:</label>
    <input type="text" name="username" id="username" />
    
    <label for="password">Password</label>
    <input type="password" name="password" id="password" />
    
    <input type="submit" value="Log in" />
    
    <input type="hidden" name="did_login" value="1" />

</form>
<?php } //end if not logged in 

else{ ?>
		
	<a href="login.php?action=logout">Log Out</a>
    
	<?php //show a welcome message if they logged in successfully
	echo 'Welcome '.$_SESSION['username'].', You are now logged in!';	
} ?>


</body>
</html>