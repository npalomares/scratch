<div id="sidebar">
	<form id="searchform" method="get" action="index.php">
    	<input type="text" name="phrase" id="phrase" placeholder="search" />
        <input type="submit" value="Search" />
    	
        <input type="hidden" name="page" value="search" />
    </form>
    <h2>Latest Posts</h2>
    <ul>
    	<?php  
		//get all published post titles, newest first
		$query_posts = "SELECT title, post_id
						FROM posts
						WHERE is_published = 1
						ORDER BY date DESC";
		//run it
		$result_posts = mysql_query( $query_posts );
		//loop it
		while( $row_posts = mysql_fetch_array( $result_posts ) ){
		 ?>
        	<li><a href="index.php?page=single&amp;postid=<?php echo $row_posts['post_id']; ?>"><?php echo $row_posts['title']; ?></a></li>
        <?php } ?>
    </ul>
    
    <h2>Categories</h2>
    <ul>
    	<?php
		//get all categories 
		$query_cats = "SELECT * FROM categories";
		//run it
		$result_cats = mysql_query( $query_cats );
		//loop it
		while( $row_cats = mysql_fetch_array( $result_cats ) ){
			//count the number of posts assigned to THIS category
			//get the cat_id of THIS category
			$category_id = $row_cats['category_id'];
			//set up query
			$query_count = "SELECT COUNT(*) AS total
							FROM posts
							WHERE category_id = $category_id";
			//run it
			$result_count = mysql_query( $query_count );
			//format the result
			$row_count = mysql_fetch_array( $result_count );
			//if the total is NOT zero, show the list item with the cat name
			if( $row_count['total'] != 0 ){
		 ?>
        		<li><?php echo $row_cats['name']; ?> (<?php echo $row_count['total']; ?>)</li>
            <?php } //end if count is not 0 ?>
       <?php } //end while loop ?>
    </ul> 
    
  <h2>Links</h2>
    <ul>
        <li>Link 1</li>
        <li>Link 2</li>
    </ul>
</div><!-- end sidebar -->